# Systemd Configuration

This directory contains configuration files for running Syncthing under the
"systemd" service manager on Linux both under either a systemd system service or
systemd user service. For further documentation take a look at the [systemd
section][1] on https://docs.syncthing.net.

[1]: https://docs.syncthing.net/users/autostart.html#using-systemd
